process.env.CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS = "1";

// Enrich process PATH at startup so binary resolution and `which` calls can find
// binaries installed via version managers (nvm, volta, fnm, etc.).
// Critical when running as a launchd/systemd service with a restricted PATH.
import { getEnrichedPath } from "./path-resolver.js";
process.env.PATH = getEnrichedPath();

import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { Hono } from "hono";
import { cors } from "hono/cors";
import { serveStatic } from "hono/bun";
import { cacheControlMiddleware } from "./cache-headers.js";
import { createRoutes } from "./routes.js";
import { CliLauncher } from "./cli-launcher.js";
import { WsBridge } from "./ws-bridge.js";
import { SessionStore } from "./session-store.js";
import { WorktreeTracker } from "./worktree-tracker.js";
import { containerManager } from "./container-manager.js";
import { join } from "node:path";
import { COMPANION_HOME } from "./paths.js";
import { TerminalManager } from "./terminal-manager.js";
import { PRPoller } from "./pr-poller.js";
import { RecorderManager } from "./recorder.js";
import { initLogFile, closeLogFile } from "./logger.js";
import { CronScheduler } from "./cron-scheduler.js";
import { AgentExecutor } from "./agent-executor.js";
import { SessionOrchestrator } from "./session-orchestrator.js";
import { migrateCronJobsToAgents } from "./agent-cron-migrator.js";
import { migrateLinearCredentialsToAgents } from "./linear-credential-migration.js";
import { LinearAgentBridge } from "./linear-agent-bridge.js";
import { NoVncProxy } from "./novnc-proxy.js";

import { startPeriodicCheck, setServiceMode } from "./update-checker.js";
import { imagePullManager } from "./image-pull-manager.js";
import { restoreIfNeeded as restoreTailscaleFunnel, cleanup as cleanupTailscaleFunnel } from "./tailscale-manager.js";
import { isRunningAsService } from "./service.js";
import { getToken, verifyToken } from "./auth-manager.js";
import { getCookie } from "hono/cookie";
import type { SocketData } from "./ws-bridge.js";
import type { ServerWebSocket } from "bun";
import { ensureTlsCerts, TLS_BRIDGE_HOSTNAME } from "./tls-manager.js";
import { checkHostsEntry } from "./hosts-check.js";
import { checkClaudeCli } from "./claude-cli-check.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const packageRoot = process.env.__COMPANION_PACKAGE_ROOT || resolve(__dirname, "..");

import { DEFAULT_PORT_DEV, DEFAULT_PORT_PROD } from "./constants.js";

const defaultPort = process.env.NODE_ENV === "production" ? DEFAULT_PORT_PROD : DEFAULT_PORT_DEV;
const port = Number(process.env.PORT) || defaultPort;
const host = process.env.HOST || "0.0.0.0";
const sessionStore = new SessionStore(process.env.COMPANION_SESSION_DIR);
const wsBridge = new WsBridge();
const launcher = new CliLauncher(port);
const worktreeTracker = new WorktreeTracker();
const CONTAINER_STATE_PATH = join(COMPANION_HOME, "containers.json");
const terminalManager = new TerminalManager();
const noVncProxy = new NoVncProxy();
const prPoller = new PRPoller(wsBridge);
const recorder = new RecorderManager();
const cronScheduler = new CronScheduler(launcher, wsBridge);
const agentExecutor = new AgentExecutor(launcher, wsBridge);
const linearAgentBridge = new LinearAgentBridge(agentExecutor, wsBridge);

const orchestrator = new SessionOrchestrator({
  launcher, wsBridge, sessionStore, worktreeTracker,
  prPoller, agentExecutor,
});

// ── Restore persisted sessions from disk ────────────────────────────────────
wsBridge.setStore(sessionStore);
wsBridge.setRecorder(recorder);
launcher.setStore(sessionStore);
launcher.setRecorder(recorder);
launcher.restoreFromDisk();
wsBridge.restoreFromDisk();
containerManager.restoreState(CONTAINER_STATE_PATH);

// ── Session orchestrator — centralizes lifecycle event wiring ────────────────
orchestrator.initialize();

console.log(`[server] Session persistence: ${sessionStore.directory}`);
if (recorder.isGloballyEnabled()) {
  console.log(`[server] Recording enabled (dir: ${recorder.getRecordingsDir()}, max: ${recorder.getMaxLines()} lines)`);
}

// ── Log file persistence — writes all log output to ~/.companion/logs/ ───────
const logFileWriter = initLogFile();
if (logFileWriter) {
  console.log(`[server] Log file enabled (dir: ${logFileWriter.getLogsDir()}, max: ${logFileWriter.getMaxLines()} lines, file: ${logFileWriter.filePath})`);
}

const app = new Hono();

// ── Health endpoint — always unauthenticated ─────────────────────────────────
const startTime = Date.now();
app.get("/health", (c) => {
  return c.json({
    ok: true,
    uptime: Math.floor((Date.now() - startTime) / 1000),
    sessions: launcher.listSessions().length,
  });
});

app.use("/api/*", cors());
app.route("/api", createRoutes(orchestrator, launcher, wsBridge, terminalManager, prPoller, recorder, cronScheduler, agentExecutor, linearAgentBridge, port));

// Dynamic manifest — embeds auth token in start_url so PWA auto-authenticates
// on first launch. iOS gives standalone PWAs isolated storage from Safari,
// so this is the only way to bridge auth across the install boundary.
app.get("/manifest.json", (c) => {
  const manifest = {
    name: "The Companion",
    short_name: "Companion",
    description: "Web UI for Claude Code and Codex",
    start_url: "/",
    scope: "/",
    display: "standalone" as const,
    background_color: "#262624",
    theme_color: "#d97757",
    icons: [
      { src: "/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
      { src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
    ],
  };

  // If the user has an auth cookie (set during login), embed token in start_url.
  // Safari sends this cookie when fetching the manifest at "Add to Home Screen" time.
  const authCookie = getCookie(c, "companion_auth");
  if (authCookie && verifyToken(authCookie)) {
    manifest.start_url = `/?token=${authCookie}`;
  } else {
    // Localhost bypass — always embed the token for same-machine installs
    const bunServer = c.env as { requestIP?: (req: Request) => { address: string } | null };
    const ip = bunServer?.requestIP?.(c.req.raw);
    const addr = ip?.address ?? "";
    if (addr === "127.0.0.1" || addr === "::1" || addr === "::ffff:127.0.0.1") {
      manifest.start_url = `/?token=${getToken()}`;
    }
  }

  c.header("Content-Type", "application/manifest+json");
  return c.json(manifest);
});

// In production, serve built frontend using absolute path (works when installed as npm package)
if (process.env.NODE_ENV === "production") {
  const distDir = resolve(packageRoot, "dist");
  app.use("/*", cacheControlMiddleware());
  app.use("/*", serveStatic({ root: distDir }));
  app.get("/*", serveStatic({ path: resolve(distDir, "index.html") }));
}

// Extract fetch/websocket handlers so they can be shared between the main
// HTTP server and the optional TLS server used for cliBridgeMode=tlsLoopback.
type AnyBunServer = import("bun").Server<SocketData>;
const fetchHandler = async (req: Request, server: AnyBunServer): Promise<Response | undefined> => {
    const url = new URL(req.url);

    // ── CLI WebSocket — Claude Code CLI connects here via --sdk-url ────
    const cliMatch = url.pathname.match(/^\/ws\/cli\/([a-f0-9-]+)$/);
    if (cliMatch) {
      const sessionId = cliMatch[1];
      // When the session was launched with cliBridgeMode === "jsonHandoff",
      // it has a one-shot bridgeToken that the spawned CLI must present
      // (either via ?token= query param or Sec-WebSocket-Protocol). This is
      // the security upgrade over passing --sdk-url on argv.
      const session = launcher.getSession(sessionId);
      if (session?.bridgeToken) {
        const presented = url.searchParams.get("token")
          || req.headers.get("sec-websocket-protocol")?.split(",").map(s => s.trim()).find(Boolean);
        if (presented !== session.bridgeToken) {
          return new Response("Unauthorized", { status: 401 });
        }
      }
      const upgraded = server.upgrade(req, {
        data: { kind: "cli" as const, sessionId },
      });
      if (upgraded) return undefined;
      return new Response("WebSocket upgrade failed", { status: 400 });
    }

    // Helper: check if request is from localhost (same machine)
    const reqIp = server.requestIP(req);
    const reqAddr = reqIp?.address ?? "";
    const isLocalhost = reqAddr === "127.0.0.1" || reqAddr === "::1" || reqAddr === "::ffff:127.0.0.1";

    // ── Browser WebSocket — connects to a specific session ─────────────
    const browserMatch = url.pathname.match(/^\/ws\/browser\/([a-f0-9-]+)$/);
    if (browserMatch) {
      const wsToken = url.searchParams.get("token");
      if (!isLocalhost && !verifyToken(wsToken)) {
        return new Response("Unauthorized", { status: 401 });
      }
      const sessionId = browserMatch[1];
      const upgraded = server.upgrade(req, {
        data: { kind: "browser" as const, sessionId },
      });
      if (upgraded) return undefined;
      return new Response("WebSocket upgrade failed", { status: 400 });
    }

    // ── Terminal WebSocket — embedded terminal PTY connection ─────────
    const termMatch = url.pathname.match(/^\/ws\/terminal\/([a-f0-9-]+)$/);
    if (termMatch) {
      const wsToken = url.searchParams.get("token");
      if (!isLocalhost && !verifyToken(wsToken)) {
        return new Response("Unauthorized", { status: 401 });
      }
      const terminalId = termMatch[1];
      const upgraded = server.upgrade(req, {
        data: { kind: "terminal" as const, terminalId },
      });
      if (upgraded) return undefined;
      return new Response("WebSocket upgrade failed", { status: 400 });
    }

    // ── noVNC WebSocket — proxies VNC data to container's websockify ────
    const novncMatch = url.pathname.match(/^\/ws\/novnc\/([a-f0-9-]+)$/);
    if (novncMatch) {
      const wsToken = url.searchParams.get("token");
      if (!isLocalhost && !verifyToken(wsToken)) {
        return new Response("Unauthorized", { status: 401 });
      }
      const sessionId = novncMatch[1];
      const upgraded = server.upgrade(req, {
        data: { kind: "novnc" as const, sessionId },
      });
      if (upgraded) return undefined;
      return new Response("WebSocket upgrade failed", { status: 400 });
    }

    // Hono handles the rest
    return app.fetch(req, server);
};

const websocketHandlers = {
  idleTimeout: 0,
  sendPings: false, // Disable Bun ping timeout that kills CLI connections (code 1006)
  open(ws: ServerWebSocket<SocketData>) {
    const data = ws.data;
    if (data.kind === "cli") {
      wsBridge.handleCLIOpen(ws, data.sessionId);
      launcher.markConnected(data.sessionId);
    } else if (data.kind === "browser") {
      wsBridge.handleBrowserOpen(ws, data.sessionId);
    } else if (data.kind === "terminal") {
      terminalManager.addBrowserSocket(ws);
    } else if (data.kind === "novnc") {
      noVncProxy.handleOpen(ws, data.sessionId);
    }
  },
  message(ws: ServerWebSocket<SocketData>, msg: string | Buffer) {
    const data = ws.data;
    if (data.kind === "cli") {
      wsBridge.handleCLIMessage(ws, msg);
    } else if (data.kind === "browser") {
      wsBridge.handleBrowserMessage(ws, msg);
    } else if (data.kind === "terminal") {
      terminalManager.handleBrowserMessage(ws, msg);
    } else if (data.kind === "novnc") {
      noVncProxy.handleMessage(ws, msg);
    }
  },
  close(ws: ServerWebSocket<SocketData>, code?: number, _reason?: string) {
    console.log("[ws-close]", ws.data.kind, "code=" + code);
    const data = ws.data;
    if (data.kind === "cli") {
      wsBridge.handleCLIClose(ws);
    } else if (data.kind === "browser") {
      wsBridge.handleBrowserClose(ws);
    } else if (data.kind === "terminal") {
      terminalManager.removeBrowserSocket(ws);
    } else if (data.kind === "novnc") {
      noVncProxy.handleClose(ws);
    }
  },
};

const server = Bun.serve<SocketData>({
  hostname: host,
  port,
  idleTimeout: 0, // Disable top-level idle timeout — it kills idle browser WebSockets (code 1006)
  fetch: fetchHandler,
  websocket: websocketHandlers,
});

// ── Embedded TLS proxy for Claude Code 2.1.142+ --sdk-url allowlist ─────────
// Claude Code 2.1.142 hardcodes a list of permitted Anthropic hostnames for
// --sdk-url and rejects ws://127.0.0.1 outright. To keep loopback working we
// (a) generate a self-signed cert for an allowlisted hostname, (b) listen on
// TLS port 8443 with that cert, and (c) advise the user to map the hostname
// to 127.0.0.1 in /etc/hosts. NODE_EXTRA_CA_CERTS makes the spawned CLI
// trust our cert.
//
// All of this is opt-in via `cliBridgeMode === "tlsLoopback"`. If cert
// generation or the TLS bind fails we log a warning and continue with just
// the HTTP server — sessions configured for loopback/jsonHandoff still work.
const tlsPort = Number(process.env.COMPANION_TLS_PORT) || 8443;
try {
  const tlsResult = await ensureTlsCerts();
  if (tlsResult.ok) {
    launcher.setTlsCaPath(tlsResult.caPath);
    try {
      Bun.serve<SocketData>({
        hostname: host,
        port: tlsPort,
        idleTimeout: 0,
        tls: {
          cert: Bun.file(tlsResult.certPath),
          key: Bun.file(tlsResult.keyPath),
        },
        fetch: fetchHandler,
        websocket: websocketHandlers,
      });
      console.log(`[server] TLS bridge listening on https://${host}:${tlsPort} (CA: ${tlsResult.caPath})`);
    } catch (err) {
      console.warn(
        `[server] Failed to start TLS bridge on port ${tlsPort}: ${err instanceof Error ? err.message : String(err)}. ` +
        `cliBridgeMode=tlsLoopback will not work; loopback/jsonHandoff sessions continue normally.`,
      );
    }
  } else {
    console.warn(
      `[server] TLS bridge disabled: ${tlsResult.reason}. ` +
      `cliBridgeMode=tlsLoopback will not work until openssl is available.`,
    );
  }
} catch (err) {
  console.warn(`[server] ensureTlsCerts threw: ${err instanceof Error ? err.message : String(err)}`);
}

// ── /etc/hosts diagnostic — warn loudly if the loopback mapping is missing ──
const hostsCheck = checkHostsEntry(TLS_BRIDGE_HOSTNAME);
if (!hostsCheck.ok) {
  console.warn(
    `[server] WARNING: ${hostsCheck.hostsPath} is missing the ${TLS_BRIDGE_HOSTNAME} → 127.0.0.1 mapping. ` +
    `Claude Code 2.1.142+ sessions using cliBridgeMode=tlsLoopback will fail to spawn. Run:\n  ${hostsCheck.suggestedCommand}`,
  );
}

// ── Claude CLI compatibility diagnostic (for stdio bridge mode) ─────────────
const cliCheck = checkClaudeCli();
if (cliCheck.found) {
  console.log(`[server] Claude CLI: ${cliCheck.version ?? "unknown version"}${cliCheck.ok ? "" : " — INCOMPATIBLE"}`);
}
if (!cliCheck.ok) {
  console.warn(`[server] WARNING: ${cliCheck.reason} Run:\n  ${cliCheck.suggestedCommand}`);
}

const authToken = getToken();
console.log(`Server running on http://${host}:${server.port}`);
console.log();
console.log(`  Auth token: ${authToken}`);
if (process.env.COMPANION_AUTH_TOKEN) {
  console.log("  (using COMPANION_AUTH_TOKEN env var)");
}
console.log();
console.log(`  CLI WebSocket:     ws://localhost:${server.port}/ws/cli/:sessionId`);
console.log(`  Browser WebSocket: ws://localhost:${server.port}/ws/browser/:sessionId`);

if (process.env.NODE_ENV !== "production") {
  console.log("Dev mode: frontend at http://localhost:5174");
}

// ── Cron scheduler ──────────────────────────────────────────────────────────
cronScheduler.startAll();

// ── Agent system ────────────────────────────────────────────────────────────
migrateCronJobsToAgents();
migrateLinearCredentialsToAgents();
agentExecutor.startAll();

// ── Image pull manager — pre-pull missing Docker images for environments ────
imagePullManager.initFromEnvironments();

// ── Tailscale Funnel restoration ────────────────────────────────────────────
restoreTailscaleFunnel(port).catch((err) => {
  console.warn("[server] Tailscale Funnel restoration failed:", err);
});

// ── Update checker ──────────────────────────────────────────────────────────
startPeriodicCheck();
if (isRunningAsService()) {
  setServiceMode(true);
  console.log("[server] Running as background service (auto-update available)");
}

// ── Runtime diagnostics ──────────────────────────────────────────────────────
import { log } from "./logger.js";
import { metricsCollector } from "./metrics-collector.js";

const DIAGNOSTICS_INTERVAL_MS = 5 * 60_000; // every 5 minutes
setInterval(() => {
  const snap = metricsCollector.getSnapshot(wsBridge);
  const mem = snap.gauges.memory;
  const mb = (bytes: number) => (bytes / 1024 / 1024).toFixed(1);
  const sessionStats = wsBridge.getSessionMemoryStats();
  const topSessions = sessionStats
    .sort((a, b) => b.historyLen - a.historyLen)
    .slice(0, 3)
    .map((s) => `${s.id.slice(0, 8)}(h=${s.historyLen},b=${s.browsers})`)
    .join(", ");

  log.info("diagnostics", "Runtime snapshot", {
    rss: `${mb(mem.rss)}MB`,
    heap: `${mb(mem.heapUsed)}/${mb(mem.heapTotal)}MB`,
    external: `${mb(mem.external)}MB`,
    sessions: snap.gauges.totalActiveSessions,
    browsers: snap.gauges.connectedBrowsers,
    historyMsgs: snap.gauges.totalHistoryMessages,
    pendingMsgs: snap.gauges.totalPendingMessages,
    eventBuffer: snap.gauges.totalEventBufferSize,
    errors: Object.values(snap.counters.errors).reduce((a, b) => a + b, 0),
    topSessions: topSessions || "none",
  });
}, DIAGNOSTICS_INTERVAL_MS);

// ── Graceful shutdown — persist container state ──────────────────────────────
function gracefulShutdown() {
  console.log("[server] Persisting container state before shutdown...");
  containerManager.persistState(CONTAINER_STATE_PATH);
  cleanupTailscaleFunnel(port);
  closeLogFile();
  process.exit(0);
}
process.on("SIGTERM", gracefulShutdown);
process.on("SIGINT", gracefulShutdown);

